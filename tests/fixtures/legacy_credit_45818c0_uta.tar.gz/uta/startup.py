"""Private, single-attempt owned initialization; never a verification cache.

Financial authority remains the persistent writer fence. This scope only lets
the spawned initializer run the original complete verifiers in read snapshots
while a separate restricted connection renews that exact live token.
"""
from __future__ import annotations

from copy import copy
from contextlib import contextmanager
import math
import os
import re
from threading import Event, RLock, Thread, get_ident
from time import monotonic

from .storage import StorageError


class StartupError(StorageError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


_ACTIVE_LOCK = RLock()
_ACTIVE = {}  # (device, inode) -> private scope; process-local, never persisted.


def _initialization_scope(database):
    with _ACTIVE_LOCK:
        if not _ACTIVE:
            return None
        matching = next((scope for scope in _ACTIVE.values() if scope.path == database.path), None)
        if matching is None:
            try:
                info = os.stat(database.path, follow_symlinks=False)
            except FileNotFoundError:
                return None  # An unrelated new authority follows normal creation.
            matching = _ACTIVE.get((info.st_dev, info.st_ino))
        return matching


@contextmanager
def _initialization_write_gate(database, role):
    """Schedule owned writes before SQLite, never retry a SQL operation.

    Read verification and independent producers retain their original paths.
    The registry/metadata locks are never held while waiting for this gate.
    """
    scope = _initialization_scope(database) if role in ("financial", "control") else None
    if scope is None:
        yield
        return
    def check():
        if role == "financial":
            scope._require(database)
        else:
            if not scope._active:
                raise StartupError("startup_context_invalid", "initialization write scope ended while waiting")
            scope.check()
            scope._check_identity(database)
    check()
    until = min(scope.deadline, monotonic() + scope.lease_seconds)
    while True:
        check()
        remaining = until - monotonic()
        if remaining <= 0:
            check()  # Preserve any already recorded keeper failure as primary.
            raise StartupError("startup_write_gate_timeout", "initialization write scheduling exceeded its lease budget")
        if scope._write_gate.acquire(timeout=min(.05, remaining)):
            break
    try:
        check()
        yield
    finally:
        scope._write_gate.release()


def _assert_initialization_actor(database):
    """Called AFTER BEGIN by every financial-role transaction, before DML.

    The ordinary inactive path adds no filesystem check. Both inode and path
    are considered so aliases and replacement paths do not bypass exclusion.
    """
    with _ACTIVE_LOCK:
        if not _ACTIVE:
            return
        matching = next((scope for scope in _ACTIVE.values() if scope.path == database.path), None)
        if matching is None:
            info = os.stat(database.path, follow_symlinks=False)
            matching = _ACTIVE.get((info.st_dev, info.st_ino))
        if matching is not None:
            matching._require(database)


class _OwnedStartup:
    """Internal worker lifecycle, not an application-supplied success receipt.

    No context may attest success without executing the original verifiers.
    Defaults of public service constructors never select this path.
    """
    def __init__(self, database, *, lease_seconds, stop, parent_pid, timeout=60.0,
                 normal_cache_size=0):
        if (isinstance(lease_seconds, bool) or not isinstance(lease_seconds, (int, float))
                or not math.isfinite(lease_seconds) or not .001 <= lease_seconds <= 3600):
            raise ValueError("lease seconds must be finite and in .001..3600")
        if (isinstance(timeout, bool) or not isinstance(timeout, (int, float))
                or not math.isfinite(timeout) or not .01 <= timeout <= 300):
            raise ValueError("startup timeout must be finite and in .01..300 seconds")
        if database.writer_token is None:
            raise StartupError("startup_token_required", "owned initialization requires a bound writer")
        if type(normal_cache_size) is not int or not 0 <= normal_cache_size <= 65536:
            raise ValueError("normal_cache_size requires an integer in 0..65536")
        self._normal_cache_size = normal_cache_size
        self.database, self.token = database, database.writer_token
        self.path, self.owner_thread = database.path, get_ident()
        info = os.stat(self.path, follow_symlinks=False)
        database._validate_private_info(info)
        self.identity = (info.st_dev, info.st_ino)
        self.stop, self.parent_pid = stop, parent_pid
        self.lease_seconds, self.timeout = lease_seconds, float(timeout)
        self._keeper_stop = Event()
        self._lock = RLock()
        self._write_gate = RLock()
        self._failure = None
        self._active = self._finished = self._entered = False
        self._keeper = None
        self._exchange = self._credit = self._ledger = None
        self._prepared_worker = None
        self._worker_taken = False
        self._ledger_verified = False
        self._verified_schema = None
        self.last_renew_started = None

    def _fail(self, exc):
        with self._lock:
            if self._failure is None:
                self._failure = exc

    def check(self):
        with self._lock:
            failure = self._failure
        if failure is not None:
            raise StartupError("startup_keeper_failed", "owned initialization lost its renewal/verification lifecycle") from failure
        if self.stop.is_set() or os.getppid() != self.parent_pid:
            raise StartupError("startup_cancelled", "initializer was stopped or lost its parent")
        if monotonic() >= self.deadline:
            raise StartupError("startup_deadline", "owned initialization exceeded its finite work budget")

    def _require(self, database):
        if not self._active or get_ident() != self.owner_thread:
            raise StartupError("initialization_in_progress", "another actor cannot write an initializing authority")
        if database.path != self.path or database.writer_token != self.token:
            raise StartupError("startup_token_conflict", "initializer authority, generation or nonce differs")
        self.check()
        self._check_identity(database)

    def _check_identity(self, database):
        info = os.stat(self.path, follow_symlinks=False)
        database._validate_private_info(info)
        if (info.st_dev, info.st_ino) != self.identity:
            raise StartupError("startup_identity_changed", "authority file changed during initialization")

    def _renew(self):
        from .writer_fence import WriterFence
        self.check()
        self._check_identity(self.database)
        started = monotonic()
        # Copy preserves bound-shard identity checks and the token. This role
        # permits lease-control writes only, never financial data or DDL.
        keeper_database = copy(self.database)
        keeper_database.timeout = min(self.database.timeout, self.lease_seconds / 12, .1)
        WriterFence(keeper_database).renew(self.token, self.lease_seconds)
        self._check_identity(self.database)
        with self._lock:
            self.last_renew_started = started

    def _keep(self):
        next_renew = monotonic()
        try:
            while not self._keeper_stop.is_set():
                self.check()
                now = monotonic()
                if now >= next_renew:
                    self._renew()
                    next_renew = self.last_renew_started + self.lease_seconds / 3
                self._keeper_stop.wait(min(.05, max(0, next_renew - monotonic())))
        except BaseException as exc:
            # Even an exception after a real COMMIT is not a known successful
            # renewal. Conservatively poison this attempt; never wash it away.
            self._fail(exc)

    def __enter__(self):
        from .writer_fence import WriterFence
        if self._entered or get_ident() != self.owner_thread:
            raise StartupError("startup_context_invalid", "initialization context is single-use and thread-bound")
        self._entered = True
        self.deadline = monotonic() + self.timeout
        with _ACTIVE_LOCK:
            if self.identity in _ACTIVE or any(scope.path == self.path for scope in _ACTIVE.values()):
                raise StartupError("startup_nested", "an authority already has an initialization scope")
            _ACTIVE[self.identity] = self
            self._active = True
        try:
            self._keeper = Thread(target=self._keep, name="uta-startup-lease", daemon=True)
            self._keeper.start()
            # Drain writers that entered before registration. Acquire itself
            # drained the previous generation; this also handles same-PID actors.
            with self.database.transaction() as connection:
                WriterFence(self.database).assert_writer(connection, self.token)
                # A no-op version write requires the normal transaction-end
                # fence check as well as the entry assertion. No schema value
                # or financial projection is changed.
                connection.execute("UPDATE uta_schema SET version=version")
            return self
        except BaseException:
            self._cleanup()
            raise

    def require_database(self, database):
        with _ACTIVE_LOCK:
            if _ACTIVE.get(self.identity) is not self:
                raise StartupError("startup_context_invalid", "initialization scope is not active")
        self._require(database)

    def _schema(self, connection):
        actual = tuple(tuple(row) for row in connection.execute(
            "SELECT type,name,tbl_name,sql FROM sqlite_master ORDER BY type,name,tbl_name,sql"))
        if self._verified_schema is not None and actual != self._verified_schema:
            raise StartupError("startup_schema_changed", "the frozen verified schema inventory or definition changed")
        return actual

    def require_trading_schema(self, database, audit_required):
        self.require_database(database)
        with database.read_transaction() as connection:
            versions = [row[0] for row in connection.execute("SELECT version FROM uta_schema")]
            columns = {row[1] for row in connection.execute("PRAGMA table_info(uta_orders)")}
            if versions != [3 if audit_required else 2] or not {"fee_notional", "charged_fee"} <= columns:
                raise StartupError("startup_offline_upgrade_required", "managed startup cannot migrate a historical trading schema")

    @staticmethod
    def _validate_module(connection, statements, version=None):
        expected = {}
        for statement in statements:
            matched = re.match(r"CREATE (TABLE|TRIGGER|(?:UNIQUE )?INDEX) IF NOT EXISTS ([a-z_]+)\b", statement)
            if matched is None:
                raise StartupError("startup_fixed_schema_invalid", "compiled startup schema is not a declared fixed object")
            kind, name = matched.groups()
            table = name if kind == "TABLE" else re.search(r"\bON ([a-z_]+)\b", statement).group(1)
            expected[name] = ("index" if "INDEX" in kind else kind.lower(), table,
                              statement.replace(" IF NOT EXISTS", "", 1))
        actual = tuple(tuple(row) for row in connection.execute(
            "SELECT name,type,tbl_name,sql FROM sqlite_master WHERE name IN (" +
            ",".join("?" for _ in expected) + ") ORDER BY name,type,tbl_name,sql", tuple(expected)))
        if not actual:
            return  # Only a wholly absent module can use fixed initialization.
        if actual != tuple(sorted((name, *definition) for name, definition in expected.items())):
            raise StartupError("startup_module_corrupt", "an existing runtime module is partial or differs from its fixed definitions")
        if version is not None:
            table, required = version
            rows = [tuple(row) for row in connection.execute("SELECT singleton,version FROM " + table)]
            if rows != [(1, required)]:
                raise StartupError("startup_offline_upgrade_required", "managed startup cannot migrate a historical runtime module")

    def prepare_schema(self, exchange):
        from .credit import CreditService
        from .matching import Matcher
        from .supervisor import ExchangeWorker
        self.require_database(exchange.database)
        if self._prepared_worker is not None or self._exchange is not None:
            raise StartupError("startup_context_reused", "startup schema preparation is single-use")
        with self.database.read_transaction() as connection:
            self._validate_module(connection, CreditService._schema_statements() + (CreditService._pool_index(),), ("credit_schema", 2))
            self._validate_module(connection, Matcher._schema_statements(), ("uta_matching_schema", 1))
            self._validate_module(connection, (ExchangeWorker._schedule_schema(),))
        with self.database.transaction() as connection:
            CreditService._schema(connection)
        # Source-defined constructor only: initializes matcher/scheduler metadata,
        # creates an Event, but never starts, supervises, matches or moves cash.
        self._prepared_worker = ExchangeWorker(exchange, normal_cache_size=self._normal_cache_size)

    def take_worker(self, exchange, *, account_batch, matches_per_symbol, normal_cache_size=0):
        from .supervisor import ExchangeWorker
        self.require_ledger(exchange)
        if self._credit is None or self._worker_taken or self._prepared_worker is None:
            raise StartupError("startup_not_verified", "prepared worker is single-use after complete credit verification")
        if (type(account_batch) is not int or not 1 <= account_batch <= 1000
                or type(matches_per_symbol) is not int or not 1 <= matches_per_symbol <= 1000):
            raise ValueError("worker scheduling bounds require integers in 1..1000")
        if type(normal_cache_size) is not int or not 0 <= normal_cache_size <= 65536:
            raise ValueError("normal_cache_size requires an integer in 0..65536")
        worker = self._prepared_worker
        if (type(worker) is not ExchangeWorker or worker.exchange is not exchange
                or worker._normal_capacity != self._normal_cache_size
                or normal_cache_size != self._normal_cache_size
                or worker._thread is not None or worker.last_report != {"state": "not_started"}
                or worker.normal_cache_stats()["size"] != 0):
            raise StartupError("startup_worker_configuration_conflict", "the native prepared worker configuration or lifecycle changed")
        worker.account_batch, worker.matches_per_symbol = account_batch, matches_per_symbol
        self._worker_taken = True
        return worker

    def verify_ledger(self, exchange):
        from .writer_fence import WriterFence
        self.require_database(exchange.database)
        if self._exchange is not None:
            raise StartupError("startup_context_reused", "ledger verification cannot be reused")
        self._exchange = exchange
        self._ledger = exchange.ledger
        with self.database.read_transaction() as connection:
            WriterFence(self.database).assert_writer(connection, self.token)
            exchange.ledger.verify(connection=connection)
            schema = self._schema(connection)
        # The read snapshot's lease row is deliberately NOT checked afterward:
        # it predates concurrent successful renewals. Fresh binding happens later.
        self.check()
        self._verified_schema = schema
        self._ledger_verified = True

    def require_ledger(self, exchange):
        self.require_database(exchange.database)
        if self._exchange is not exchange or self._ledger is not exchange.ledger or not self._ledger_verified:
            raise StartupError("startup_not_verified", "this exact exchange has not completed full replay")

    def verify_credit(self, credit):
        from .writer_fence import WriterFence
        self.require_ledger(credit.exchange)
        if self._credit is not None:
            raise StartupError("startup_context_reused", "credit verification cannot be reused")
        with self.database.read_transaction() as connection:
            WriterFence(self.database).assert_writer(connection, self.token)
            self._schema(connection)
            credit._verify(connection)
            self._schema(connection)
        self.check()
        self._credit = credit

    def finish(self):
        """Stop keeper, fresh renew/bind and COMMIT before permitting READY."""
        from .writer_fence import WriterFence
        self.require_database(self.database)
        if self._finished or not self._ledger_verified or self._credit is None:
            raise StartupError("startup_not_verified", "complete exchange and credit verification is required")
        self.require_ledger(self._exchange)
        if self._credit.ledger is not self._ledger:
            raise StartupError("startup_not_verified", "verified credit ledger identity changed")
        self._stop_keeper()
        self.check()
        self._renew()
        with self.database.transaction() as connection:
            self._require(self.database)
            WriterFence(self.database).assert_writer(connection, self.token)
            self._schema(connection)
            connection.execute("UPDATE uta_schema SET version=version")
        self.check()
        self._finished = True

    def _stop_keeper(self):
        self._keeper_stop.set()
        if self._keeper is not None and self._keeper.ident is not None:
            self._keeper.join(timeout=1)
            if self._keeper.is_alive():
                raise StartupError("startup_keeper_stuck", "startup renewal did not drain")

    def _cleanup(self):
        try:
            self._stop_keeper()
        finally:
            with _ACTIVE_LOCK:
                if _ACTIVE.get(self.identity) is self:
                    del _ACTIVE[self.identity]
                self._active = False

    def __exit__(self, exc_type, exc, traceback):
        self._cleanup()
        if exc_type is None and not self._finished:
            raise StartupError("startup_not_finished", "owned initialization did not complete its final binding")
